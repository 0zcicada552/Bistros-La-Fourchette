var modal = document.getElementById("myModal");
var btnOpen = document.getElementById("openModal");
var btnOpenReservation = document.getElementById("openReservationModal");
var btnClose = document.querySelector(".close");


if (btnOpen) {
    btnOpen.onclick = function () {
        modal.classList.add("show");
    };
}

if (btnOpenReservation) {
    btnOpenReservation.onclick = function () {
        modal.classList.add("show");
    };
}

if (btnClose) {
    btnClose.onclick = function () {
        modal.classList.remove("show");
    };
}


window.onclick = function (event) {
    if (event.target === modal) {
        modal.classList.remove("show");
    }
};
